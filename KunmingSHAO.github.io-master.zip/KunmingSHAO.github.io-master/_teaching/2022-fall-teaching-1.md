---
title: "Analog Electronics"
collection: teaching
type: "Undergraduate course"
permalink: /teaching/2022-fall-teaching-1
venue: "SCUT"
date: 2022-09-21
location: "Guangzhou, China"
---

This is the course for Chinese Postgraduate Entrance Examination. I was the lecturer of this unofficial course, and we used Neamen's Microelectronics: Circuit Analysis And Design, Fourth Edition

